package com.example.simplecalendar

import android.os.Bundle
import android.widget.CalendarView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var calendarView: CalendarView
    private lateinit var textViewDate: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize the views
        calendarView = findViewById(R.id.calendarView)
        textViewDate = findViewById(R.id.textViewDate)

        // Set the default date when the calendar is first displayed
        val currentDate = Calendar.getInstance().time
        updateDateText(currentDate)

        // Listener for date changes
        calendarView.setOnDateChangeListener { _, year, month, dayOfMonth ->
            // Adjust month to be 0-indexed for Calendar class
            val selectedDate = Calendar.getInstance().apply {
                set(year, month, dayOfMonth)
            }.time
            updateDateText(selectedDate)
        }
    }

    // Function to update the date text view
    private fun updateDateText(date: Date) {
        // Formatting the date
        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        textViewDate.text = "Selected Date: ${dateFormat.format(date)}"
    }
}
