package com.example.simplecalculator

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var textViewResult: TextView

    private var currentInput: String = ""
    private var previousInput: String = ""
    private var operator: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // Linking to activity_main.xml

        textViewResult = findViewById(R.id.textViewResult)

        // Number buttons
        val button0: Button = findViewById(R.id.button0)
        val button1: Button = findViewById(R.id.button1)
        val button2: Button = findViewById(R.id.button2)
        val button3: Button = findViewById(R.id.button3)
        val button4: Button = findViewById(R.id.button4)
        val button5: Button = findViewById(R.id.button5)
        val button6: Button = findViewById(R.id.button6)
        val button7: Button = findViewById(R.id.button7)
        val button8: Button = findViewById(R.id.button8)
        val button9: Button = findViewById(R.id.button9)

        // Operator buttons
        val buttonAdd: Button = findViewById(R.id.buttonAdd)
        val buttonSubtract: Button = findViewById(R.id.buttonSubtract)
        val buttonMultiply: Button = findViewById(R.id.buttonMultiply)
        val buttonDivide: Button = findViewById(R.id.buttonDivide)
        val buttonEqual: Button = findViewById(R.id.buttonEqual)
        val buttonClear: Button = findViewById(R.id.buttonClear)

        // Set click listeners for number buttons
        button0.setOnClickListener { appendToInput("0") }
        button1.setOnClickListener { appendToInput("1") }
        button2.setOnClickListener { appendToInput("2") }
        button3.setOnClickListener { appendToInput("3") }
        button4.setOnClickListener { appendToInput("4") }
        button5.setOnClickListener { appendToInput("5") }
        button6.setOnClickListener { appendToInput("6") }
        button7.setOnClickListener { appendToInput("7") }
        button8.setOnClickListener { appendToInput("8") }
        button9.setOnClickListener { appendToInput("9") }

        // Set click listeners for operator buttons
        buttonAdd.setOnClickListener { setOperator("+") }
        buttonSubtract.setOnClickListener { setOperator("-") }
        buttonMultiply.setOnClickListener { setOperator("*") }
        buttonDivide.setOnClickListener { setOperator("/") }

        // Set click listener for equal button
        buttonEqual.setOnClickListener { calculateResult() }

        // Set click listener for clear button
        buttonClear.setOnClickListener { clearInput() }
    }

    private fun appendToInput(value: String) {
        currentInput += value
        textViewResult.text = currentInput
    }

    private fun setOperator(op: String) {
        if (currentInput.isNotEmpty()) {
            previousInput = currentInput
            operator = op
            currentInput = ""
        }
    }

    private fun calculateResult() {
        if (currentInput.isNotEmpty() && previousInput.isNotEmpty() && operator != null) {
            val result = when (operator) {
                "+" -> previousInput.toDouble() + currentInput.toDouble()
                "-" -> previousInput.toDouble() - currentInput.toDouble()
                "*" -> previousInput.toDouble() * currentInput.toDouble()
                "/" -> if (currentInput.toDouble() != 0.0) {
                    previousInput.toDouble() / currentInput.toDouble()
                } else {
                    // Handle division by zero
                    "Error"
                }
                else -> "Error"
            }
            textViewResult.text = result.toString()
            clearInput() // Clear inputs after calculating the result
        }
    }

    private fun clearInput() {
        currentInput = ""
        previousInput = ""
        operator = null
        textViewResult.text = "0" // Reset display to 0
    }
}