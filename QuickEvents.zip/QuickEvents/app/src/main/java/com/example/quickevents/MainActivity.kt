package com.example.eventcreationapp

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var editTextEventName: EditText
    private lateinit var editTextEventDate: EditText
    private lateinit var buttonAddEvent: Button
    private lateinit var textViewEventList: TextView

    private val eventList = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextEventName = findViewById(R.id.editTextEventName)
        editTextEventDate = findViewById(R.id.editTextEventDate)
        buttonAddEvent = findViewById(R.id.buttonAddEvent)
        textViewEventList = findViewById(R.id.textViewEventList)

        buttonAddEvent.setOnClickListener { addEvent() }
    }

    private fun addEvent() {
        val eventName = editTextEventName.text.toString()
        val eventDate = editTextEventDate.text.toString()

        if (eventName.isNotEmpty() && eventDate.isNotEmpty()) {
            val event = "$eventName on $eventDate"
            eventList.add(event)
            displayEvents()
            clearInputs()
        } else {
            textViewEventList.text = "Please enter both event name and date."
        }
    }

    private fun displayEvents() {
        textViewEventList.text = eventList.joinToString("\n")
    }

    private fun clearInputs() {
        editTextEventName.text.clear()
        editTextEventDate.text.clear()
    }
}